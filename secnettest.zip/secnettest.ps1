# PowerShell script file to be executed as a AWS Lambda function. 
# 
# When executing in Lambda the following variables will be predefined.
#   $LambdaInput - A PSObject that contains the Lambda function input data.
#   $LambdaContext - An Amazon.Lambda.Core.ILambdaContext object that contains information about the currently running Lambda environment.
#
# The last item in the PowerShell pipeline will be returned as the result of the Lambda function.
#
# To include PowerShell modules with your Lambda function, like the AWS.Tools.S3 module, add a "#Requires" statement
# indicating the module and version. If using an AWS.Tools.* module the AWS.Tools.Common module is also required.

#Requires -Modules @{ModuleName='AWS.Tools.Common';ModuleVersion='4.1.9.0'}
#Requires -Modules @{ModuleName='AWS.Tools.CodePipeline';ModuleVersion='4.1.9.0'}

$LambdaJS = (ConvertTo-Json -InputObject $LambdaInput -Compress -Depth 5)

$ALBDNSName = ($LambdaJS | Select-String -Pattern '"secnet-ALB1-(.*?)"').Matches.Value
$JobId = ((($LambdaJS.Split(':')[2]).Replace('"','')).Replace(',','')).Replace('accountId','')

Write-host $JobId
Write-Host $JobId.GetType()

[string] $_URL = "http://" + $ALBDNSName.Replace('"','')

$request = Invoke-WebRequest -SkipCertificateCheck -Uri $_URL
    $output = @{
        RequestUri = $_URL
        SiteURI = $request.BaseResponse.RequestMessage.RequestUri.AbsoluteUri
        StatusCode = $request.StatusCode.ToString()
        Status = $request.StatusDescription
    }

$output

If ($output.StatusCode -eq "200"){
    Write-CPJobSuccessResult -JobId $JobId -OutputVariable $output
}else {
    $message = "Web Test failed with " + $output.StatusCode
    Write-CPJobFailureResult -JobId $JobId -FailureDetails_Type JobFailed -FailureDetails_Message $message
}
    

# Uncomment to send the input event to CloudWatch Logs
Write-Host (ConvertTo-Json -InputObject $LambdaInput -Compress -Depth 5)

